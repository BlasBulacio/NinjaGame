﻿using UnityEngine;
using System.Collections;

public class Pinches : MonoBehaviour {
    public NinjaScript traerFuncion;
    void Start()
    {
        traerFuncion = GameObject.Find("NinjaConAnimacion").GetComponent<NinjaScript>();
    }
    void OnCollisionEnter2D(Collision2D col)
    {
        traerFuncion.Muerte(); 
    }
}