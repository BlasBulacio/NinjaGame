﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class NinjaScript : MonoBehaviour {

    // Use this for initialization
    Rigidbody2D ninjibody;
    public bool colisiona = true;
    float Camarax;
   //GameObject CanvasFinal;
    float Camaray;
    public LayerMask GroundLayer;
    bool PuedeSaltar = true;
    public Animator Animacion;
    bool pausa;
    
    void Start() {
        ninjibody = gameObject.GetComponent<Rigidbody2D>();
        pausa = true;
        //CanvasFinal = GameObject.Find("Canvas");

    }

    // Update is called once per frame
    void Update() {
       
        ninjibody.velocity = new Vector2(3f, ninjibody.velocity.y);
        if (Input.GetKeyDown(KeyCode.Space) && (colisiona) && (PuedeSaltar))
        {
            ninjibody.velocity = new Vector2(0.0f,0.0f);
            ninjibody.AddForce(new Vector2(0.0f, 400.0f));
            colisiona = false;
        }


        if (ninjibody.position.x > 17.43f)
        {
            ninjibody.velocity = Vector2.zero;
            PuedeSaltar = false;
            Application.LoadLevel(1);

            //CanvasFinal.SetActive(true);
            //CanvasFinal.GetComponent<Canvas>().enabled = true;

        }

        if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (pausa)
                    Time.timeScale = 1;
               
                else
                    Time.timeScale = 0;
            pausa = !pausa;
            
        }


    }
    //

    
    void LateUpdate() {  
        Camera.main.transform.position = new Vector2(transform.position.x + Camarax, Camaray);
        if (transform.position.y < -6f)
        {
            Muerte();
        }

    }

    void OnCollisionEnter2D(Collision2D col)
    {
        //Physics2D.BoxCast
        RaycastHit2D hit = Physics2D.BoxCast(Vector2.zero,new Vector2(2f,2f),0f,Vector2.down,0.9f);
        if (hit.
            collider != null) colisiona = true;
    }

    /*public void OnGUI()
    {
        alpha += fadeDir * fadeSpeed * Time.deltaTime;
        alpha = Mathf.Clamp01(alpha);
        GUI.color = new Color(GUI.color.r, GUI.color.g, GUI.color.b, alpha);
        GUI.depth = drawDepth;
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), fadeOutTexture);   
    }*/


    public void Muerte() //Esta función retorna al ninja al principio del juego.xd -_-
    {


            Animacion.SetTrigger("SANGRE");
        Scene nivel = SceneManager.GetActiveScene();

        SceneManager.LoadScene(nivel.name);


    }
}

        