﻿using UnityEngine;
using System.Collections;

public class SiguienteNivel : MonoBehaviour {

	// Use this for initialization
	public void Siguiente() {
        Application.LoadLevel(2);
	}
    public void Volver()
    {
        Application.LoadLevel(0);
    }

    // Update is called once per frame

}
