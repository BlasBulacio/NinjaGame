﻿using UnityEngine;
using System.Collections;

public class MenuPausa : MonoBehaviour {

    NinjaScript NinjaScript = new NinjaScript();

    // Use this for initialization
    public void Reanudar () {
        NinjaScript.MenuPausa = GameObject.Find("FinalCanvas").GetComponent<Canvas>();

        NinjaScript.MenuPausa.enabled=false;

        Time.timeScale = 1;
    }

    public void Volver()
    {
        Application.LoadLevel(0);
    }


}
