﻿using UnityEngine;
using System.Collections;

public class Menu : MonoBehaviour {
    public void Jugar() {
        Application.LoadLevel(1);
	}

    public void Salir()
    {
        Application.Quit();
        
    }
    

}
