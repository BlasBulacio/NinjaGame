﻿using UnityEngine;
using System.Collections;

public class NinjaScript : MonoBehaviour {

    // Use this for initialization
    Rigidbody2D ninjibody;
    public bool colisiona = true;
    float Camarax;
    float Camaray;
    public LayerMask GroundLayer;
    void Start() {
        ninjibody = gameObject.GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update() {
        ninjibody.velocity = new Vector2(3f, ninjibody.velocity.y);
        if (Input.GetKeyDown(KeyCode.Space) && (colisiona))
        {
            ninjibody.AddForce(new Vector2(0.0f, 400.0f));
            colisiona = false;
        }
    }
    //
    void LateUpdate() {
        Camera.main.transform.position = new Vector2(transform.position.x + Camarax, Camaray);
        if (transform.position.y < -6f)
        {
            transform.position = new Vector2(-2.7f,-0.5f);
        }
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        //Physics2D.BoxCast
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 0.9f, GroundLayer);
        if (hit.collider != null) colisiona = true;
    }
}

