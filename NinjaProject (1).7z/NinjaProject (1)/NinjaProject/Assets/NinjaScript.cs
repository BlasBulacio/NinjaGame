﻿using UnityEngine;
using System.Collections;

public class NinjaScript : MonoBehaviour {

    // Use this for initialization
    Rigidbody2D ninjibody;
    public bool colisiona = true;
    float Camarax;
    float Camaray;
    public LayerMask GroundLayer;
    public Texture2D fadeOutTexture;    //La textura que va a llenar 
    public float fadeSpeed = 0.1f;
    public float alpha = 1.0f;
    public int drawDepth = -1000;
    public int fadeDir = -1;
    bool PuedeSaltar = true;
    void Start() {
        ninjibody = gameObject.GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update() {
        ninjibody.velocity = new Vector2(3f, ninjibody.velocity.y);
        if (Input.GetKeyDown(KeyCode.Space) && (colisiona) && (PuedeSaltar))
        {
            ninjibody.AddForce(new Vector2(0.0f, 400.0f));
            colisiona = false;
        }

        if (ninjibody.position.x > 16.109f)
        {
            ninjibody.velocity = Vector2.zero;
            PuedeSaltar = false;
            OnGUI();
            BeginFade(-1);
        }
    }
    //
    void LateUpdate() {
        Camera.main.transform.position = new Vector2(transform.position.x + Camarax, Camaray);
        if (transform.position.y < -6f)
        {
            transform.position = new Vector2(-2.7f,-0.5f);
        }
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        //Physics2D.BoxCast
        RaycastHit2D hit = Physics2D.BoxCast(Vector2.zero,new Vector2(2f,2f),0f,Vector2.down,0.9f);
        if (hit.collider != null) colisiona = true;
    }

    public void OnGUI()
    {
        alpha += fadeDir * fadeSpeed * Time.deltaTime;
        alpha = Mathf.Clamp01(alpha);
        GUI.color = new Color(GUI.color.r, GUI.color.g, GUI.color.b, alpha);
        GUI.depth = drawDepth;
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), fadeOutTexture);   
    }

    public float BeginFade (int direction)
    {
        fadeDir = direction;
        return (fadeSpeed);
    }
}

